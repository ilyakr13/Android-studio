package com.example.secondproject

interface VoiceInterface {
    fun loudVoice(): String
    fun quietVoice(): String
}
