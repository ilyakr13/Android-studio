package com.example.secondproject

class Fish(name: String) : Animal(name) {
    val canSwim = true
}
